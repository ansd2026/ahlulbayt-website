<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Islamic School – Ahlul Bayt Islamic Center Columbus</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=Tajawal:wght@300;400;500&family=Cinzel:wght@400;600&display=swap" rel="stylesheet">
<style>
  :root {
    --green: #1a4a2e;
    --green-mid: #2d6e47;
    --green-light: #4a9e6b;
    --gold: #c9a84c;
    --gold-light: #e8c97a;
    --cream: #faf6ef;
    --cream-dark: #f0e9da;
    --text: #1c1c1c;
    --text-soft: #5a5a5a;
    --white: #ffffff;
  }

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  html { scroll-behavior: smooth; }

  body {
    font-family: 'Tajawal', sans-serif;
    background: var(--cream);
    color: var(--text);
    overflow-x: hidden;
  }

  .geo-pattern {
    position: fixed; top: 0; left: 0; width: 100%; height: 100%;
    opacity: 0.03; pointer-events: none; z-index: 0;
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='80' height='80'%3E%3Cpath d='M40 0 L80 40 L40 80 L0 40Z' fill='none' stroke='%231a4a2e' stroke-width='1'/%3E%3Cpath d='M40 10 L70 40 L40 70 L10 40Z' fill='none' stroke='%231a4a2e' stroke-width='0.5'/%3E%3Ccircle cx='40' cy='40' r='15' fill='none' stroke='%231a4a2e' stroke-width='0.5'/%3E%3C/svg%3E");
  }

  /* ─── NAVBAR ─── */
  nav {
    position: fixed; top: 0; left: 0; right: 0; z-index: 100;
    display: flex; align-items: center; justify-content: space-between;
    padding: 0 5%; height: 72px;
    background: rgba(26, 74, 46, 0.97);
    backdrop-filter: blur(12px);
    border-bottom: 1px solid rgba(201, 168, 76, 0.3);
  }

  .nav-brand {
    display: flex; align-items: center; gap: 12px;
    text-decoration: none;
  }
  .nav-logo {
    width: 42px; height: 42px; background: var(--gold);
    border-radius: 50%; display: flex; align-items: center; justify-content: center;
    font-family: 'Cormorant Garamond', serif; font-size: 20px;
    color: var(--green); font-weight: 600; flex-shrink: 0;
  }
  .nav-title {
    font-family: 'Cinzel', serif; font-size: 13px;
    color: var(--gold-light); line-height: 1.3; letter-spacing: 0.05em;
  }
  .nav-title span {
    display: block; font-size: 10px;
    color: rgba(255,255,255,0.55); letter-spacing: 0.1em; text-transform: uppercase;
  }

  .nav-links { display: flex; gap: 36px; list-style: none; align-items: center; }
  .nav-links a {
    text-decoration: none; color: rgba(255,255,255,0.8);
    font-size: 13px; letter-spacing: 0.08em; text-transform: uppercase;
    transition: color 0.2s; position: relative;
  }
  .nav-links a::after {
    content: ''; position: absolute; bottom: -4px; left: 0; right: 0;
    height: 1px; background: var(--gold);
    transform: scaleX(0); transition: transform 0.2s;
  }
  .nav-links a:hover { color: var(--gold-light); }
  .nav-links a:hover::after { transform: scaleX(1); }
  .nav-links a.active { color: var(--gold-light); }
  .nav-links a.active::after { transform: scaleX(1); }

  .nav-donate {
    background: var(--gold) !important; color: var(--green) !important;
    padding: 8px 20px !important; border-radius: 2px; font-weight: 500;
  }
  .nav-donate:hover { background: var(--gold-light) !important; }
  .nav-donate::after { display: none !important; }

  .hamburger { display: none; flex-direction: column; gap: 5px; cursor: pointer; padding: 8px; }
  .hamburger span { width: 24px; height: 2px; background: var(--gold-light); border-radius: 2px; }

  /* ─── PAGE HERO ─── */
  .page-hero {
    margin-top: 120px;
    background: linear-gradient(160deg, #0e2c1a 0%, #1a4a2e 50%, #2d6e47 100%);
    padding: 90px 5% 80px;
    position: relative; overflow: hidden;
  }
  .page-hero::before {
    content: '';
    position: absolute; right: -100px; top: -100px;
    width: 500px; height: 500px;
    border-radius: 50%;
    border: 1px solid rgba(201,168,76,0.1);
  }
  .page-hero::after {
    content: '';
    position: absolute; right: -50px; top: -50px;
    width: 380px; height: 380px;
    border-radius: 50%;
    border: 1px solid rgba(201,168,76,0.07);
  }

  .page-hero-inner { max-width: 1200px; margin: 0 auto; position: relative; z-index: 1; }

  .breadcrumb {
    display: flex; align-items: center; gap: 8px;
    font-size: 12px; letter-spacing: 0.1em; text-transform: uppercase;
    color: rgba(255,255,255,0.45); margin-bottom: 24px;
  }
  .breadcrumb a { color: var(--gold); text-decoration: none; }
  .breadcrumb a:hover { color: var(--gold-light); }
  .breadcrumb span { color: rgba(255,255,255,0.25); }

  .page-hero-tag {
    font-size: 12px; letter-spacing: 0.2em; text-transform: uppercase;
    color: var(--gold); margin-bottom: 16px;
  }

  .page-hero-title {
    font-family: 'Cormorant Garamond', serif;
    font-size: clamp(38px, 6vw, 72px);
    color: var(--white); line-height: 1.1; font-weight: 300;
    margin-bottom: 20px;
  }
  .page-hero-title em { color: var(--gold-light); font-style: italic; }

  .page-hero-desc {
    font-size: 16px; color: rgba(255,255,255,0.65);
    line-height: 1.8; max-width: 580px; margin-bottom: 40px;
  }

  .hero-stats {
    display: flex; gap: 48px; flex-wrap: wrap;
  }
  .hero-stat-num {
    font-family: 'Cormorant Garamond', serif;
    font-size: 42px; color: var(--gold-light); font-weight: 300; line-height: 1;
  }
  .hero-stat-label {
    font-size: 11px; letter-spacing: 0.12em; text-transform: uppercase;
    color: rgba(255,255,255,0.45); margin-top: 4px;
  }

  /* ─── SECTION SHARED ─── */
  section { position: relative; z-index: 1; }

  .section-tag { font-size: 11px; letter-spacing: 0.2em; text-transform: uppercase; color: var(--green-mid); margin-bottom: 12px; }
  .section-title { font-family: 'Cormorant Garamond', serif; font-size: clamp(28px, 4vw, 44px); color: var(--green); line-height: 1.2; font-weight: 400; }
  .section-title em { color: var(--gold); font-style: italic; }
  .section-line { width: 50px; height: 2px; background: linear-gradient(90deg, var(--gold), transparent); margin: 16px 0 28px; }

  /* ─── OVERVIEW ─── */
  .overview { padding: 90px 5%; }
  .overview-inner {
    max-width: 1200px; margin: 0 auto;
    display: grid; grid-template-columns: 1fr 1fr; gap: 80px; align-items: center;
  }
  .overview-text p { font-size: 16px; line-height: 1.9; color: var(--text-soft); margin-bottom: 18px; }

  .overview-visual {
    display: grid; grid-template-columns: 1fr 1fr; gap: 3px;
  }
  .overview-stat-card {
    background: var(--green); padding: 36px 28px;
    position: relative; overflow: hidden;
  }
  .overview-stat-card:first-child { border-radius: 4px 0 0 0; }
  .overview-stat-card:nth-child(2) { border-radius: 0 4px 0 0; background: var(--green-mid); }
  .overview-stat-card:nth-child(3) { border-radius: 0 0 0 4px; background: var(--green-mid); }
  .overview-stat-card:last-child { border-radius: 0 0 4px 0; }

  .overview-stat-num {
    font-family: 'Cormorant Garamond', serif;
    font-size: 48px; color: var(--gold-light); font-weight: 300; line-height: 1;
    margin-bottom: 8px;
  }
  .overview-stat-label { font-size: 12px; letter-spacing: 0.08em; color: rgba(255,255,255,0.6); line-height: 1.4; }

/* ─── GUIDELINES & POLICIES ─── */
  .policies { background: var(--cream-dark); padding: 90px 5%; }
  .policies-inner { max-width: 1200px; margin: 0 auto; }
  .policies-header { text-align: center; margin-bottom: 64px; }
  .policies-header .section-line { margin: 16px auto 28px; }

  .policies-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 24px;
  }

  .policy-card {
    background: var(--white);
    border-radius: 4px;
    overflow: hidden;
    border: 1px solid rgba(26,74,46,0.08);
    transition: transform 0.3s, box-shadow 0.3s;
  }
  .policy-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 20px 50px rgba(26,74,46,0.1);
  }

  .policy-card-header {
    background: var(--green);
    padding: 24px 32px;
    display: flex; align-items: center; gap: 14px;
    position: relative; overflow: hidden;
  }
  .policy-card-header::after {
    content: '';
    position: absolute; bottom: 0; left: 0; right: 0;
    height: 2px;
    background: linear-gradient(90deg, var(--gold), transparent);
  }
  .policy-card-icon {
    font-size: 26px; flex-shrink: 0;
  }
  .policy-card-title {
    font-family: 'Cinzel', serif;
    font-size: 15px; color: var(--gold-light);
    letter-spacing: 0.05em;
  }

  .policy-card-body { padding: 32px; }

  .policy-rule {
    padding: 16px 0;
    border-bottom: 1px solid rgba(26,74,46,0.07);
  }
  .policy-rule:last-child { border-bottom: none; padding-bottom: 0; }
  .policy-rule:first-child { padding-top: 0; }

  .policy-rule-label {
    display: flex; align-items: center; gap: 8px;
    font-family: 'Cinzel', serif;
    font-size: 12px; letter-spacing: 0.08em;
    color: var(--green); margin-bottom: 8px;
    text-transform: uppercase;
  }
  .policy-rule-label::before {
    content: '';
    width: 6px; height: 6px; border-radius: 50%;
    background: var(--gold); flex-shrink: 0;
  }

  .policy-rule-text {
    font-size: 14px; line-height: 1.8;
    color: var(--text-soft);
  }

  .policy-badge {
    display: inline-flex; align-items: center; gap: 6px;
    background: rgba(201,168,76,0.12);
    color: var(--green);
    border: 1px solid rgba(201,168,76,0.3);
    font-size: 11px; letter-spacing: 0.08em;
    padding: 5px 12px; border-radius: 20px;
    margin-top: 10px; font-weight: 500;
  }
  .policy-badge::before { content: '⚠'; font-size: 11px; }

  /* ─── CURRICULUM ─── */
  .curriculum { padding: 90px 5%; }
  .curriculum-inner { max-width: 1200px; margin: 0 auto; }
  .curriculum-grid {
    display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 24px;
    margin-top: 48px;
  }

  .curriculum-card {
    border: 1px solid rgba(26,74,46,0.1);
    border-radius: 2px; padding: 36px;
    transition: border-color 0.2s, transform 0.2s;
    background: var(--white);
  }
  .curriculum-card:hover { border-color: var(--gold); transform: translateY(-2px); }

  .curriculum-icon {
    width: 56px; height: 56px;
    background: linear-gradient(135deg, var(--green), var(--green-mid));
    border-radius: 4px; display: flex; align-items: center; justify-content: center;
    font-size: 24px; margin-bottom: 20px;
  }

  .curriculum-title {
    font-family: 'Cinzel', serif; font-size: 15px; color: var(--green);
    margin-bottom: 12px; letter-spacing: 0.04em;
  }
  .curriculum-desc { font-size: 14px; line-height: 1.8; color: var(--text-soft); }

  /* ─── SCHEDULE ─── */
  .schedule { background: var(--green); padding: 90px 5%; position: relative; overflow: hidden; }
  .schedule::before {
    content: '';
    position: absolute; inset: 0;
    background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='100'%3E%3Ccircle cx='50' cy='50' r='40' fill='none' stroke='rgba(255,255,255,0.03)' stroke-width='1'/%3E%3C/svg%3E");
  }

  .schedule-inner { max-width: 1200px; margin: 0 auto; position: relative; z-index: 1; }
  .schedule-inner .section-tag { color: var(--gold); }
  .schedule-inner .section-title { color: var(--white); }
  .schedule-inner .section-line { background: linear-gradient(90deg, var(--gold), transparent); }

  .schedule-grid {
    display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 20px;
    margin-top: 48px;
  }

  .schedule-card {
    background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.1);
    border-radius: 2px; padding: 32px 28px;
    transition: background 0.2s;
  }
  .schedule-card:hover { background: rgba(255,255,255,0.1); }

  .schedule-time {
    font-family: 'Cormorant Garamond', serif;
    font-size: 28px; color: var(--gold-light); font-weight: 300; margin-bottom: 4px;
  }
  .schedule-label { font-size: 11px; letter-spacing: 0.12em; text-transform: uppercase; color: rgba(255,255,255,0.45); margin-bottom: 14px; }
  .schedule-title { font-family: 'Cinzel', serif; font-size: 14px; color: var(--white); margin-bottom: 8px; }
  .schedule-desc { font-size: 13px; color: rgba(255,255,255,0.5); line-height: 1.6; }

  /* ─── ENROLLMENT CTA ─── */
  .enroll { padding: 90px 5%; }
  .enroll-inner {
    max-width: 1100px; margin: 0 auto;
    background: linear-gradient(135deg, #0e2c1a, #1a4a2e);
    border-radius: 4px; padding: 80px;
    display: grid; grid-template-columns: 1fr 1fr; gap: 60px; align-items: center;
    position: relative; overflow: hidden;
  }
  .enroll-inner::before {
    content: '';
    position: absolute; right: -80px; bottom: -80px;
    width: 300px; height: 300px; border-radius: 50%;
    border: 1px solid rgba(201,168,76,0.1);
  }

  .enroll-text .section-tag { color: var(--gold); }
  .enroll-text .section-title { color: var(--white); }
  .enroll-text .section-line { background: linear-gradient(90deg, var(--gold), transparent); }
  .enroll-text p { font-size: 15px; color: rgba(255,255,255,0.6); line-height: 1.8; }

  .enroll-form { position: relative; z-index: 1; }

  .form-group { margin-bottom: 18px; }
  .form-label { display: block; font-size: 11px; letter-spacing: 0.1em; text-transform: uppercase; color: rgba(255,255,255,0.5); margin-bottom: 8px; }
  .form-input, .form-select {
    width: 100%; padding: 12px 16px;
    background: rgba(255,255,255,0.07); border: 1px solid rgba(255,255,255,0.15);
    border-radius: 2px; color: var(--white);
    font-family: 'Tajawal', sans-serif; font-size: 14px;
    transition: border-color 0.2s;
    -webkit-appearance: none;
  }
  .form-input::placeholder { color: rgba(255,255,255,0.3); }
  .form-input:focus, .form-select:focus { outline: none; border-color: var(--gold); }
  .form-select option { background: var(--green); color: var(--white); }

  .btn-primary {
    background: var(--gold); color: var(--green);
    padding: 14px 36px; border: none; border-radius: 2px;
    font-family: 'Tajawal', sans-serif; font-size: 14px; font-weight: 500;
    letter-spacing: 0.1em; text-transform: uppercase;
    cursor: pointer; transition: all 0.2s; width: 100%; margin-top: 6px;
  }
  .btn-primary:hover { background: var(--gold-light); transform: translateY(-2px); }

  /* ─── FAQ ─── */
  .faq { background: var(--cream-dark); padding: 90px 5%; }
  .faq-inner { max-width: 800px; margin: 0 auto; }
  .faq-header { text-align: center; margin-bottom: 48px; }
  .faq-header .section-line { margin: 16px auto 28px; }

  .faq-item {
    border-bottom: 1px solid rgba(26,74,46,0.1);
    padding: 24px 0; cursor: pointer;
  }
  .faq-item:first-of-type { border-top: 1px solid rgba(26,74,46,0.1); }

  .faq-question {
    display: flex; justify-content: space-between; align-items: center; gap: 20px;
    font-family: 'Cormorant Garamond', serif; font-size: 20px; color: var(--green);
    font-weight: 400;
  }
  .faq-toggle {
    width: 28px; height: 28px; flex-shrink: 0;
    background: rgba(26,74,46,0.08); border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    font-size: 16px; color: var(--green); transition: transform 0.3s, background 0.2s;
  }
  .faq-item.open .faq-toggle { transform: rotate(45deg); background: var(--gold); color: var(--green); }

  .faq-answer {
    max-height: 0; overflow: hidden;
    transition: max-height 0.4s ease, padding 0.3s;
    font-size: 15px; line-height: 1.8; color: var(--text-soft);
  }
  .faq-item.open .faq-answer { max-height: 300px; padding-top: 16px; }

  /* ─── FOOTER ─── */
  footer { background: #0e2c1a; padding: 60px 5% 30px; color: rgba(255,255,255,0.5); }
  .footer-inner {
    max-width: 1200px; margin: 0 auto;
    display: grid; grid-template-columns: 2fr 1fr 1fr; gap: 60px;
    padding-bottom: 48px; border-bottom: 1px solid rgba(255,255,255,0.08); margin-bottom: 30px;
  }
  .footer-brand-name { font-family: 'Cinzel', serif; font-size: 16px; color: var(--gold-light); margin-bottom: 8px; }
  .footer-brand-sub { font-size: 12px; letter-spacing: 0.1em; margin-bottom: 20px; }
  .footer-desc { font-size: 13px; line-height: 1.8; }
  .footer-col-title { font-family: 'Cinzel', serif; font-size: 12px; letter-spacing: 0.1em; color: var(--gold); margin-bottom: 20px; text-transform: uppercase; }
  .footer-links { list-style: none; }
  .footer-links li { margin-bottom: 10px; }
  .footer-links a { font-size: 13px; color: rgba(255,255,255,0.5); text-decoration: none; transition: color 0.2s; }
  .footer-links a:hover { color: var(--gold-light); }
  .footer-bottom { max-width: 1200px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; font-size: 12px; }
  .footer-bottom a { color: var(--gold); text-decoration: none; }

  /* ─── SUB NAV BAR ─── */
  .sub-nav {
    position: fixed;
    top: 72px; left: 0; right: 0;
    z-index: 99;
    background: rgba(15, 40, 25, 0.97);
    backdrop-filter: blur(12px);
    border-bottom: 1px solid rgba(201,168,76,0.2);
    overflow-x: auto;
    scrollbar-width: none;
  }
  .sub-nav::-webkit-scrollbar { display: none; }

  .sub-nav-inner {
    max-width: 1200px; margin: 0 auto;
    display: flex; align-items: stretch;
    padding: 0 5%;
  }

  .sub-nav-link {
    display: flex; align-items: center; gap: 8px;
    padding: 14px 20px;
    text-decoration: none;
    color: rgba(255,255,255,0.55);
    font-size: 12px; letter-spacing: 0.08em;
    text-transform: uppercase; white-space: nowrap;
    border-bottom: 2px solid transparent;
    transition: color 0.2s, border-color 0.2s, background 0.2s;
  }
  .sub-nav-link:hover {
    color: var(--gold-light);
    background: rgba(255,255,255,0.04);
  }
  .sub-nav-link.active {
    color: var(--gold-light);
    border-bottom-color: var(--gold);
  }
  .sub-nav-link .sub-icon { font-size: 13px; }

  /* ─── ANIMATIONS ─── */
  .fade-in { opacity: 0; transform: translateY(24px); transition: opacity 0.7s ease, transform 0.7s ease; }
  .fade-in.visible { opacity: 1; transform: none; }

  @media (max-width: 900px) {
    .overview-inner { grid-template-columns: 1fr; gap: 48px; }
    .enroll-inner { grid-template-columns: 1fr; padding: 48px 32px; gap: 40px; }
    .footer-inner { grid-template-columns: 1fr 1fr; }
    .nav-links { display: none; }
    .hamburger { display: flex; }
  }
  @media (max-width: 600px) {
    .footer-inner { grid-template-columns: 1fr; gap: 40px; }
    .hero-stats { gap: 28px; }
  }

  /* ─── CALENDAR ─── */
  .calendar-section { padding: 90px 5%; background: var(--cream); }
  .calendar-inner { max-width: 1200px; margin: 0 auto; }
  .calendar-layout {
    display: grid; grid-template-columns: 1fr 340px; gap: 40px; margin-top: 48px; align-items: start;
  }

  .cal-widget {
    background: var(--white); border: 1px solid rgba(26,74,46,0.1);
    border-radius: 4px; overflow: hidden;
  }
  .cal-header {
    background: var(--green); padding: 20px 28px;
    display: flex; align-items: center; justify-content: space-between;
  }
  .cal-month-label {
    font-family: 'Cinzel', serif; font-size: 16px;
    color: var(--gold-light); letter-spacing: 0.05em;
  }
  .cal-nav { display: flex; gap: 8px; }
  .cal-nav-btn {
    width: 32px; height: 32px; border-radius: 50%;
    background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.2);
    color: rgba(255,255,255,0.8); cursor: pointer; font-size: 14px;
    display: flex; align-items: center; justify-content: center;
    transition: background 0.2s;
  }
  .cal-nav-btn:hover { background: rgba(255,255,255,0.2); }

  .cal-grid { padding: 20px; }
  .cal-days-header {
    display: grid; grid-template-columns: repeat(7, 1fr);
    margin-bottom: 8px;
  }
  .cal-day-name {
    text-align: center; font-size: 10px; letter-spacing: 0.1em;
    text-transform: uppercase; color: var(--text-soft); padding: 6px 0;
    font-weight: 500;
  }
  .cal-day-name.sunday { color: var(--green); font-weight: 700; }

  .cal-dates { display: grid; grid-template-columns: repeat(7, 1fr); gap: 3px; }
  .cal-date {
    aspect-ratio: 1; display: flex; align-items: center; justify-content: center;
    font-size: 13px; border-radius: 50%; cursor: default;
    position: relative; transition: background 0.15s;
    color: var(--text);
  }
  .cal-date.empty { opacity: 0; }
  .cal-date.sunday { color: var(--green); font-weight: 600; }
  .cal-date.has-class {
    background: rgba(26,74,46,0.1); color: var(--green);
    font-weight: 700; cursor: pointer;
  }
  .cal-date.has-class:hover { background: rgba(26,74,46,0.18); }
  .cal-date.has-event {
    background: var(--gold); color: var(--green);
    font-weight: 700; cursor: pointer;
  }
  .cal-date.has-event:hover { background: var(--gold-light); }
  .cal-date.holiday {
    background: rgba(180,60,60,0.1); color: #a33;
    text-decoration: line-through; cursor: default;
  }
  .cal-date.today {
    outline: 2px solid var(--green); outline-offset: 2px;
  }
  .cal-date .cal-dot {
    position: absolute; bottom: 3px; left: 50%; transform: translateX(-50%);
    width: 4px; height: 4px; border-radius: 50%; background: var(--gold);
  }

  .cal-legend { display: flex; gap: 20px; flex-wrap: wrap; padding: 16px 20px; border-top: 1px solid rgba(26,74,46,0.07); }
  .cal-legend-item { display: flex; align-items: center; gap: 6px; font-size: 11px; color: var(--text-soft); }
  .cal-legend-dot { width: 10px; height: 10px; border-radius: 50%; flex-shrink: 0; }

  /* event sidebar */
  .cal-events-panel { display: flex; flex-direction: column; gap: 12px; }
  .cal-events-title {
    font-family: 'Cinzel', serif; font-size: 13px; letter-spacing: 0.08em;
    color: var(--green); text-transform: uppercase; margin-bottom: 4px;
  }
  .cal-event-item {
    background: var(--white); border: 1px solid rgba(26,74,46,0.08);
    border-radius: 4px; padding: 16px 18px;
    display: flex; gap: 14px; align-items: flex-start;
    transition: border-color 0.2s, transform 0.2s;
    cursor: default;
  }
  .cal-event-item:hover { border-color: var(--gold); transform: translateX(3px); }
  .cal-event-date-box {
    flex-shrink: 0; text-align: center; width: 44px;
    background: var(--green); border-radius: 3px; padding: 6px 4px;
  }
  .cal-event-date-box .ev-month {
    font-size: 9px; letter-spacing: 0.1em; text-transform: uppercase;
    color: var(--gold); display: block;
  }
  .cal-event-date-box .ev-day {
    font-family: 'Cormorant Garamond', serif; font-size: 26px;
    color: var(--white); font-weight: 300; line-height: 1;
  }
  .cal-event-info { flex: 1; }
  .cal-event-tag {
    display: inline-block; font-size: 9px; letter-spacing: 0.1em;
    text-transform: uppercase; background: rgba(26,74,46,0.08);
    color: var(--green); padding: 2px 8px; border-radius: 2px; margin-bottom: 5px;
  }
  .cal-event-tag.gold { background: rgba(201,168,76,0.15); color: #8a6a10; }
  .cal-event-name {
    font-family: 'Cormorant Garamond', serif; font-size: 17px;
    color: var(--text); font-weight: 400; margin-bottom: 3px;
  }
  .cal-event-meta { font-size: 12px; color: var(--text-soft); }

  /* ─── PHOTO GALLERY ─── */
  .gallery-section { background: var(--green); padding: 90px 5%; position: relative; overflow: hidden; }
  .gallery-section::before {
    content: '';
    position: absolute; inset: 0;
    background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='80' height='80'%3E%3Cpath d='M40 0 L80 40 L40 80 L0 40Z' fill='none' stroke='rgba(255,255,255,0.03)' stroke-width='1'/%3E%3C/svg%3E");
  }
  .gallery-inner { max-width: 1200px; margin: 0 auto; position: relative; z-index: 1; }
  .gallery-inner .section-tag { color: var(--gold); }
  .gallery-inner .section-title { color: var(--white); }
  .gallery-inner .section-line { background: linear-gradient(90deg, var(--gold), transparent); }

  .gallery-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    grid-template-rows: auto auto;
    gap: 8px;
    margin-top: 48px;
  }
  .gallery-item {
    position: relative; overflow: hidden; border-radius: 3px;
    background: rgba(255,255,255,0.06);
    aspect-ratio: 1;
    cursor: pointer;
  }
  .gallery-item.wide { grid-column: span 2; aspect-ratio: 2/1; }
  .gallery-item.tall { grid-row: span 2; aspect-ratio: 1/2; }

  .gallery-placeholder {
    width: 100%; height: 100%; min-height: 180px;
    display: flex; flex-direction: column;
    align-items: center; justify-content: center; gap: 10px;
    background: rgba(255,255,255,0.04);
    border: 1px dashed rgba(201,168,76,0.2);
    transition: background 0.2s;
  }
  .gallery-item:hover .gallery-placeholder { background: rgba(255,255,255,0.08); }
  .gallery-placeholder-icon { font-size: 28px; opacity: 0.4; }
  .gallery-placeholder-label {
    font-size: 11px; letter-spacing: 0.1em; text-transform: uppercase;
    color: rgba(255,255,255,0.3); text-align: center; padding: 0 10px;
  }

  .gallery-overlay {
    position: absolute; inset: 0;
    background: linear-gradient(to top, rgba(0,0,0,0.6) 0%, transparent 60%);
    opacity: 0; transition: opacity 0.3s;
    display: flex; align-items: flex-end; padding: 14px;
  }
  .gallery-item:hover .gallery-overlay { opacity: 1; }
  .gallery-overlay-label {
    font-size: 12px; color: rgba(255,255,255,0.9);
    letter-spacing: 0.05em;
  }

  .gallery-upload-note {
    text-align: center; margin-top: 28px;
    font-size: 13px; color: rgba(255,255,255,0.4);
    letter-spacing: 0.05em;
  }
  .gallery-upload-note strong { color: var(--gold); }

  /* ─── RESPONSIVE ADDITIONS ─── */
  @media (max-width: 900px) {
    .calendar-layout { grid-template-columns: 1fr; }
    .gallery-grid { grid-template-columns: repeat(2, 1fr); }
    .gallery-item.wide { grid-column: span 2; }
    .gallery-item.tall { grid-row: span 1; aspect-ratio: 1; }
  }
  @media (max-width: 600px) {
    .gallery-grid { grid-template-columns: repeat(2, 1fr); }
  }

</style>
</head>
<body>
<div class="geo-pattern"></div>

<!-- ─── NAVBAR ─── -->
<nav>
  <a href="main index.html" class="nav-brand">
    <div class="nav-logo">☪</div>
    <div class="nav-title">
      Ahlul Bayt Islamic Center
      <span>Columbus, Ohio</span>
    </div>
  </a>
  <ul class="nav-links">
    <li><a href="https://www.ahlulbayt-columbus.org/aboutus.php">About</a></li>
    <li><a href="https://www.ahlulbayt-columbus.org/index.php">Services</a></li>
    <li><a href="https://www.ahlulbayt-columbus.org/programs.php">Events</a></li>
    <li><a href="https://www.ahlulbayt-columbus.org/support.php" class="nav-donate">Donate</a></li>
  </ul>
  <div class="hamburger" onclick="toggleMenu(this)">
    <span></span><span></span><span></span>
  </div>
</nav>

<!-- ─── SUB NAV BAR ─── -->
<div class="sub-nav" id="subNav">
  <div class="sub-nav-inner">
    <a href="#about" class="sub-nav-link"><span class="sub-icon">🕌</span> Mission &amp; Vision</a>
    <a href="#programs" class="sub-nav-link"><span class="sub-icon">📋</span> Guidelines &amp; Policies</a>
    <a href="#curriculum" class="sub-nav-link"><span class="sub-icon">📖</span> Curriculum</a>
    <a href="#schedule" class="sub-nav-link"><span class="sub-icon">🕐</span> Sunday Schedule</a>
    <a href="#enroll" class="sub-nav-link"><span class="sub-icon">✏️</span> Enroll</a>
    <a href="#calendar" class="sub-nav-link"><span class="sub-icon">📅</span> Calendar</a>
    <a href="#gallery" class="sub-nav-link"><span class="sub-icon">🖼️</span> Gallery</a>
    <a href="#faq" class="sub-nav-link"><span class="sub-icon">❓</span> FAQ</a>
  </div>
</div>

<!-- ─── PAGE HERO ─── -->
<div class="page-hero">
  <div class="page-hero-inner">
    <div class="breadcrumb">
      <a href="index (4).html">Home</a>
      <span>›</span>
      <span>Islamic School</span>
    </div>
    <div class="page-hero-tag">Education & Youth Development</div>
    <h1 class="page-hero-title">Ahlul Bayt<br><em>Islamic School</em></h1>
    <p class="page-hero-desc">
      Nurturing the next generation of Muslim leaders through authentic Islamic education, rooted in the teachings of the Prophet Muhammad (PBUH) and the Ahlul-Bayt.
    </p>
    <div class="hero-stats">
      <div>
        <div class="hero-stat-num">5</div>
        <div class="hero-stat-label">Guidelines & Policies</div>
      </div>
      <div>
        <div class="hero-stat-num">3</div>
        <div class="hero-stat-label">Core Subjects</div>
      </div>
      <div>
        <div class="hero-stat-num">Sun</div>
        <div class="hero-stat-label">Weekly Classes</div>
      </div>
    </div>
  </div>
</div>

<!-- ─── OVERVIEW ─── -->
<section class="overview" id="about">
  <div class="overview-inner">
    <div class="overview-text fade-in">
      <div class="section-tag">Our Mission</div>
      <h2 class="section-title">Faith, Knowledge,<br><em>Character</em></h2>
      <div class="section-line"></div>
      <p>
        The Ahlul Bayt Sunday School <em><b>mission</b></em> is to educate students on Quran, Islamic values, and history, and to foster a strong sense of community among young Muslims. We aim to instill in them strong character and morals, preparing them to become responsible members of our society.
      </p>
      <p>
        Our <em>vision</em> is to create a safe and nurturing environment where students can learn and grow in their faith, with the ultimate goal of becoming positive role models for future generations of Muslims.      
      </p>
      <p>
        Classes are held every Sunday morning at the center, welcoming students from preschool through high school age.
      </p>
    </div>
    <div class="overview-visual fade-in">
      <div class="overview-stat-card">
        <div class="overview-stat-num">Level 1<br>Ages 5–6</div>
        <div class="overview-stat-label">Kindergarden and 1st grade program</div>
      </div>
      <div class="overview-stat-card">
        <div class="overview-stat-num">Level 2<br>Ages 7–9</div>
        <div class="overview-stat-label">2nd and 3rd grade program</div>
      </div>
      <div class="overview-stat-card">
        <div class="overview-stat-num">Level 3<br>Ages 10–12</div>
        <div class="overview-stat-label">4th and 5th grade Program</div>
      </div>
      <div class="overview-stat-card">
        <div class="overview-stat-num">Level 4<br>Ages 13–15</div>
        <div class="overview-stat-label">Middle School Program</div>
      </div>
       <div class="overview-stat-card">
        <div class="overview-stat-num">Level 5<br>Ages 16+</div>
        <div class="overview-stat-label">High School Program</div>
      </div>
    </div>
  </div>
</section>

<!-- ─── GUIDELINES & POLICIES ─── -->
<section class="policies" id="programs">
  <div class="policies-inner">
    <div class="policies-header fade-in">
      <div class="section-tag">What You Need to Know</div>
      <h2 class="section-title">Guidelines &amp; <em>Policies</em></h2>
      <div class="section-line"></div>
      <p style="max-width:580px; margin: 0 auto; font-size:15px; color:var(--text-soft); line-height:1.8;">
        To ensure a safe, respectful, and spiritually enriching environment for all students, please review the following guidelines before enrolling your child.
      </p>
    </div>

    <div class="policies-grid">

      <!-- GENERAL GUIDELINES -->
      <div class="policy-card fade-in">
        <div class="policy-card-header">
          <div class="policy-card-icon">📋</div>
          <div class="policy-card-title">General Guidelines</div>
        </div>
        <div class="policy-card-body">
          <div class="policy-rule">
            <div class="policy-rule-label">Age Requirement</div>
            <p class="policy-rule-text">Minimum age required at the time of registration is 5 years (attending Kindergarten at the new school year).</p>
          </div>
          <div class="policy-rule">
            <div class="policy-rule-label">Dress Code</div>
            <p class="policy-rule-text">The dress code of all participants of the Sunday School must comply with the Islamic requirements.</p>
          </div>
        </div>
      </div>

      <!-- ATTENDANCE -->
      <div class="policy-card fade-in">
        <div class="policy-card-header">
          <div class="policy-card-icon">🗓️</div>
          <div class="policy-card-title">Attendance</div>
        </div>
        <div class="policy-card-body">
          <div class="policy-rule">
            <div class="policy-rule-label">Punctuality</div>
            <p class="policy-rule-text">Parents are requested to bring their children regularly and ON TIME to the school. Parents must also pick up their children on time. The school administration will not be held liable if students are not picked up by the assigned pick-up time.</p>
          </div>
          <div class="policy-rule">
            <div class="policy-rule-label">Absences</div>
            <p class="policy-rule-text">The student's success at the Sunday School is dependent on their regular attendance. Therefore, if a child is absent for 3 consecutive Sundays, parents need to schedule a meeting with the Sunday School administration for the child to be able to continue at the school. In addition, readmission of the student might be required.</p>
            <span class="policy-badge">3 absences triggers readmission review</span>
          </div>
        </div>
      </div>

      <!-- CONDUCT & BEHAVIOR -->
      <div class="policy-card fade-in">
        <div class="policy-card-header">
          <div class="policy-card-icon">🤝</div>
          <div class="policy-card-title">Conduct &amp; Behavior</div>
        </div>
        <div class="policy-card-body">
          <div class="policy-rule">
            <div class="policy-rule-label">Islamic Conduct</div>
            <p class="policy-rule-text">ABS Sunday School expects all students to behave according to the teachings of Quran, prophets, and Ahlul-Bayt. Therefore, students are expected to show respect to themselves, other students, teachers, and faculty at the school.</p>
          </div>
          <div class="policy-rule">
            <div class="policy-rule-label">Respect for Others</div>
            <p class="policy-rule-text">All students are expected to treat fellow classmates, teachers, and staff with kindness and respect at all times. Disrespectful behavior toward any member of the school community will not be tolerated.</p>
          </div>
          <div class="policy-rule">
            <div class="policy-rule-label">Zero Tolerance</div>
            <p class="policy-rule-text">Bullying, harassment, or any form of harmful behavior — physical or verbal — is strictly prohibited and will result in immediate action by the school administration.</p>
            <span class="policy-badge">Zero tolerance for bullying</span>
          </div>
          <div class="policy-rule">
            <div class="policy-rule-label">Phones & Devices</div>
            <p class="policy-rule-text">Mobile phones and personal devices must be put away and silenced during class time. Students using devices during lessons will be asked to put them away.</p>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- ─── CURRICULUM HIGHLIGHTS ─── -->
<section class="curriculum" id="curriculum">
  <div class="curriculum-inner">
    <div class="fade-in">
      <div class="section-tag">What We Teach</div>
      <h2 class="section-title">Our Core <em>Curriculum</em></h2>
      <div class="section-line"></div>
    </div>
    <div class="curriculum-grid">

      <div class="curriculum-card fade-in">
        <div class="curriculum-icon">🕌</div>
        <div class="curriculum-title">Islamic Studies</div>
        <p class="curriculum-desc">
          A comprehensive curriculum covering the fundamentals of Islamic belief (Aqeedah), worship (Fiqh), and ethics (Akhlaq). Students learn the five pillars, Islamic jurisprudence, and how to live as a practicing Muslim in today's world. Lessons are age-appropriate and grounded in authentic scholarship.
        </p>
      </div>

      <div class="curriculum-card fade-in">
        <div class="curriculum-icon">⭐</div>
        <div class="curriculum-title">Ahlul-Bayt History</div>
        <p class="curriculum-desc">
          A dedicated study of the life and teachings of the Prophet Muhammad (PBUH) and his blessed household — the fourteen infallibles. Students explore the character, wisdom, and sacrifices of the Imams (AS), and understand how their teachings continue to guide Muslims today. Special focus is given to Karbala and its lasting lessons.
        </p>
      </div>

      <div class="curriculum-card fade-in">
        <div class="curriculum-icon">🤲</div>
        <div class="curriculum-title">Duas & Worship</div>
        <p class="curriculum-desc">
          Students learn the essential daily Duas, short Surahs, and the correct way to perform Salah and other acts of worship. Older students are introduced to the rich tradition of Dua literature from the Ahlul-Bayt, including selections from Sahifa al-Sajjadiyya.
        </p>
      </div>

      <div class="curriculum-card fade-in">
        <div class="curriculum-icon">💎</div>
        <div class="curriculum-title">Character & Values</div>
        <p class="curriculum-desc">
          Woven throughout all our classes is an emphasis on Islamic character — honesty, kindness, respect, and service. Students are encouraged to embody the values taught by the Prophet and Imams in their relationships with family, friends, and their wider community.
        </p>
      </div>

    </div>
  </div>
</section>

<!-- ─── SUNDAY SCHEDULE ─── -->
<section class="schedule" id="schedule">
  <div class="schedule-inner">
    <div class="section-tag fade-in">Every Sunday Morning</div>
    <h2 class="section-title fade-in">A Typical <em>Sunday</em></h2>
    <div class="section-line fade-in"></div>
    <div class="schedule-grid">
      <div class="schedule-card fade-in">
        <div class="schedule-time">9:55</div>
        <div class="schedule-label">AM — Arrival</div>
        <div class="schedule-title">Welcome & Registration</div>
        <div class="schedule-desc">Students arrive, check in, and settle into their classrooms. Parents are welcome to speak with teachers during this time.</div>
      </div>
      <div class="schedule-card fade-in">
        <div class="schedule-time">10:00</div>
        <div class="schedule-label">AM — Opening</div>
        <div class="schedule-title">Morning Assembly</div>
        <div class="schedule-desc">All students gather for a short opening program — a Dua, an announcement, and an inspiring thought for the week.</div>
      </div>
      <div class="schedule-card fade-in">
        <div class="schedule-time">10:15</div>
        <div class="schedule-label">AM — Instruction</div>
        <div class="schedule-title">Classes Begin</div>
        <div class="schedule-desc">Age-group classes begin covering Islamic Studies and Ahlul-Bayt History. Interactive lessons, discussions, and activities.</div>
      </div>
      <div class="schedule-card fade-in">
        <div class="schedule-time">11:00</div>
        <div class="schedule-label">AM — Break</div>
        <div class="schedule-title">Snack & Free Time</div>
        <div class="schedule-desc">A short break for students to socialize, have a snack, and recharge before the second lesson block.</div>
      </div>
      <div class="schedule-card fade-in">
        <div class="schedule-time">11:15</div>
        <div class="schedule-label">AM — Second Block</div>
        <div class="schedule-title">Second Lesson</div>
        <div class="schedule-desc">Continuation of the curriculum — Duas, stories, group projects, or special programs depending on the age group.</div>
      </div>
      <div class="schedule-card fade-in">
        <div class="schedule-time">1:00</div>
        <div class="schedule-label">PM — Dismissal</div>
        <div class="schedule-title">Closing & Pick-Up</div>
        <div class="schedule-desc">Students are dismissed to their parents. Teachers are available for questions. Optional: stay for Dhuhr prayer.</div>
      </div>
    </div>
  </div>
</section>

<!-- ─── ENROLLMENT FORM ─── -->
<section class="enroll" id="enroll">
  <div class="enroll-inner">
    <div class="enroll-text fade-in">
      <div class="section-tag">Join the School</div>
      <h2 class="section-title">Enroll Your<br><em>Child Today</em></h2>
      <div class="section-line"></div>
      <p>
        Enrollment is open to all Muslim children in the Columbus area. Classes are held every Sunday morning at Ahlul Bayt Islamic Center, 2580 W Dublin-Granville Rd, Columbus, OH 43235.
      </p>
      <br>
      <p>
        For questions about the school, please contact the Islamic School office or speak to the school administrator after Sunday prayers.
      </p>
    </div>
    <div class="enroll-form fade-in" style="background:transparent;">
      <iframe
        src="https://docs.google.com/forms/d/e/1FAIpQLSdOOsulPSF_s5DUqHvVqHQ4rOKAbTcUBOwzswMTVnGbxzzlaQ/viewform?embedded=true"
        width="100%"
        height="1014"
        frameborder="0"
        marginheight="0"
        marginwidth="0"
        style="border:none; border-radius:4px; display:block; background:white;">
        Loading…
      </iframe>
    </div>
  </div>
</section>


<!-- ─── CALENDAR & EVENTS ─── -->
<section class="calendar-section" id="calendar">
  <div class="calendar-inner">
    <div class="fade-in">
      <div class="section-tag">Stay Up to Date</div>
      <h2 class="section-title">Calendar &amp; Upcoming <em>Events</em></h2>
      <div class="section-line"></div>
    </div>
    <div class="calendar-layout">

      <!-- CALENDAR WIDGET -->
      <div class="fade-in">
        <div class="cal-widget">
          <div class="cal-header">
            <div class="cal-month-label" id="calMonthLabel"></div>
            <div class="cal-nav">
              <button class="cal-nav-btn" onclick="changeMonth(-1)">&#8249;</button>
              <button class="cal-nav-btn" onclick="changeMonth(1)">&#8250;</button>
            </div>
          </div>
          <div class="cal-grid">
            <div class="cal-days-header">
              <div class="cal-day-name sunday">Sun</div>
              <div class="cal-day-name">Mon</div>
              <div class="cal-day-name">Tue</div>
              <div class="cal-day-name">Wed</div>
              <div class="cal-day-name">Thu</div>
              <div class="cal-day-name">Fri</div>
              <div class="cal-day-name">Sat</div>
            </div>
            <div class="cal-dates" id="calDates"></div>
          </div>
          <div class="cal-legend">
            <div class="cal-legend-item">
              <div class="cal-legend-dot" style="background:rgba(26,74,46,0.2)"></div> Class Day
            </div>
            <div class="cal-legend-item">
              <div class="cal-legend-dot" style="background:var(--gold)"></div> Special Event
            </div>
            <div class="cal-legend-item">
              <div class="cal-legend-dot" style="background:rgba(180,60,60,0.2)"></div> No School
            </div>
          </div>
        </div>
      </div>

      <!-- EVENTS SIDEBAR -->
      <div class="fade-in">
        <div class="cal-events-title">Upcoming Events</div>
        <div class="cal-events-panel" id="upcomingEventsList">
          <!-- Populated dynamically by JS -->
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ─── PHOTO GALLERY ─── -->
<section class="gallery-section" id="gallery">
  <div class="gallery-inner">
    <div class="fade-in">
      <div class="section-tag">Life at Sunday School</div>
      <h2 class="section-title">Our <em>Gallery</em></h2>
      <div class="section-line"></div>
    </div>
    <div class="gallery-grid">

      <div class="gallery-item wide fade-in">
        <img src="images/IMG-20260517-WA0252.jpg" alt="Graduation Picnic" style="width:100%;height:100%;object-fit:cover;display:block;">
        <div class="gallery-overlay"><div class="gallery-overlay-label">Graduation Picnic 2026</div></div>
      </div>

      <div class="gallery-item fade-in">
        <img src="images/IMG-20260517-WA0282.jpg" alt="Student Awards" style="width:100%;height:100%;object-fit:cover;display:block;">
        <div class="gallery-overlay"><div class="gallery-overlay-label">Student Awards</div></div>
      </div>

      <div class="gallery-item fade-in">
        <img src="images/IMG-20260517-WA0298.jpg" alt="Middle School Class" style="width:100%;height:100%;object-fit:cover;display:block;">
        <div class="gallery-overlay"><div class="gallery-overlay-label">Middle School Class</div></div>
      </div>

      <div class="gallery-item fade-in">
        <img src="images/IMG-20260517-WA0302.jpg" alt="Certificate Ceremony" style="width:100%;height:100%;object-fit:cover;display:block;">
        <div class="gallery-overlay"><div class="gallery-overlay-label">Certificate Ceremony</div></div>
      </div>

      <div class="gallery-item fade-in">
        <img src="images/IMG-20260517-WA0307.jpg" alt="Graduation Day" style="width:100%;height:100%;object-fit:cover;display:block;">
        <div class="gallery-overlay"><div class="gallery-overlay-label">Graduation Day</div></div>
      </div>

      <div class="gallery-item wide fade-in">
        <img src="images/20260517_112912_HDR.jpg" alt="Community Celebration" style="width:100%;height:100%;object-fit:cover;display:block;">
        <div class="gallery-overlay"><div class="gallery-overlay-label">Community Celebration</div></div>
      </div>

      <div class="gallery-item fade-in">
        <img src="images/IMG-20260517-WA0315.jpg" alt="Awards Night" style="width:100%;height:100%;object-fit:cover;display:block;">
        <div class="gallery-overlay"><div class="gallery-overlay-label">Awards Night</div></div>
      </div>

    </div>
    <div class="gallery-upload-note">
      Graduation &amp; Awards Ceremony — May 2026 · <strong>More photos coming soon!</strong>
    </div>
  </div>
</section>

<!-- ─── FAQ ─── -->
<section class="faq" id="faq">
  <div class="faq-inner">
    <div class="faq-header fade-in">
      <div class="section-tag">Common Questions</div>
      <h2 class="section-title">FAQ</h2>
      <div class="section-line"></div>
    </div>

    <div class="faq-item fade-in" onclick="toggleFaq(this)">
      <div class="faq-question">
        Is there a tuition fee for the Islamic School?
        <div class="faq-toggle">+</div>
      </div>
      <div class="faq-answer">The Tuition for classes are $30,but we do not want financial constraints to prevent any child from receiving an Islamic education. Please speak to the school administrator for more information.</div>
    </div>

    <div class="faq-item fade-in" onclick="toggleFaq(this)">
      <div class="faq-question">
        Do I need to be a member of the masjid to enroll?
        <div class="faq-toggle">+</div>
      </div>
      <div class="faq-answer">No — the Islamic School is open to all Muslim families in the Columbus area regardless of masjid membership. We welcome all children who wish to learn.</div>
    </div>

    <div class="faq-item fade-in" onclick="toggleFaq(this)">
      <div class="faq-question">
        What language are classes taught in?
        <div class="faq-toggle">+</div>
      </div>
      <div class="faq-answer">All classes are taught primarily in English to ensure all students can fully participate. Arabic words, Duas, and terms are introduced and explained throughout the curriculum.</div>
    </div>

    <div class="faq-item fade-in" onclick="toggleFaq(this)">
      <div class="faq-question">
        How do I become a teacher or volunteer?
        <div class="faq-toggle">+</div>
      </div>
      <div class="faq-answer">We are always looking for dedicated volunteers and teachers. If you are passionate about Islamic education and working with youth, please reach out to the school office or speak to the administrator after Sunday prayers. JazakAllah Khayr.</div>
    </div>

    <div class="faq-item fade-in" onclick="toggleFaq(this)">
      <div class="faq-question">
        What do I need to bring on the first day?
        <div class="faq-toggle">+</div>
      </div>
      <div class="faq-answer">Just bring your child and a willingness to learn! On the first day you will complete a short registration form. Students should arrive by 10:00 AM. A small snack for the break is welcome but not required.</div>
    </div>

  </div>
</section>


<!-- ─── FOOTER ─── -->
<footer>
  <div class="footer-inner">
    <div>
      <div class="footer-brand-name">Ahlul Bayt Islamic Center</div>
      <div class="footer-brand-sub">Columbus, Ohio</div>
      <p class="footer-desc">A place of worship, learning, and community for Muslims in Central Ohio. Rooted in the tradition of the Prophet and his blessed household.</p>
    </div>
    <div>
      <div class="footer-col-title">Quick Links</div>
      <ul class="footer-links">
        <li><a href="index.html#about">About Us</a></li>
        <li><a href="index.html#prayer-times">Prayer Times</a></li>
        <li><a href="index.html#services">Programs</a></li>
        <li><a href="index.html#events">Events</a></li>
        <li><a href="index.html#donate">Donate</a></li>
      </ul>
    </div>
    <div>
      <div class="footer-col-title">School</div>
      <ul class="footer-links">
        <li><a href="#programs">Guidelines & Policies</a></li>
        <li><a href="#curriculum">Curriculum</a></li>
        <li><a href="#schedule">Schedule</a></li>
        <li><a href="#enroll">Enroll</a></li>
        <li><a href="#faq">FAQ</a></li>
      </ul>
    </div>
  </div>
  <div class="footer-bottom">
    <div>© 2026 Ahlul Bayt Islamic Center – Columbus, Ohio. All rights reserved.</div>
    <div>Made with ❤️ for the community</div>
  </div>
</footer>

<script>
  // Fade-in on scroll
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(el => { if (el.isIntersecting) el.target.classList.add('visible'); });
  }, { threshold: 0.1 });
  document.querySelectorAll('.fade-in').forEach(el => observer.observe(el));

  // FAQ accordion
  function toggleFaq(item) {
    const isOpen = item.classList.contains('open');
    document.querySelectorAll('.faq-item').forEach(i => i.classList.remove('open'));
    if (!isOpen) item.classList.add('open');
  }

  // Enrollment button
  function handleEnroll() {
    const btn = document.querySelector('.btn-primary');
    btn.textContent = '✓ Submitted! We will be in touch.';
    btn.style.background = 'var(--green-light)';
    btn.style.color = 'white';
  }

  // Mobile menu
  function toggleMenu(btn) {
    const links = document.querySelector('.nav-links');
    links.style.display = links.style.display === 'flex' ? 'none' : 'flex';
    links.style.flexDirection = 'column';
    links.style.position = 'fixed';
    links.style.top = '72px';
    links.style.left = '0'; links.style.right = '0';
    links.style.background = 'rgba(14,44,26,0.98)';
    links.style.padding = '20px 5%';
    links.style.gap = '20px';
  }
  // ── SUB NAV ACTIVE HIGHLIGHT ON SCROLL ──
  const subNavSections = ['about', 'programs', 'curriculum', 'schedule', 'enroll', 'calendar', 'gallery', 'faq'];
  const subNavLinks = document.querySelectorAll('.sub-nav-link');

  window.addEventListener('scroll', () => {
    let current = '';
    subNavSections.forEach(id => {
      const el = document.getElementById(id);
      if (el && window.scrollY >= el.offsetTop - 160) current = id;
    });
    subNavLinks.forEach(a => {
      a.classList.toggle('active', a.getAttribute('href') === '#' + current);
    });
  });

  // ── SMOOTH SCROLL WITH OFFSET FOR FIXED BARS ──
  document.querySelectorAll('.sub-nav-link').forEach(link => {
    link.addEventListener('click', function(e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        window.scrollTo({ top: target.offsetTop - 130, behavior: 'smooth' });
      }
    });
  });
  // ── INTERACTIVE CALENDAR ──
  const events = {
    // September 2026
    '2026-9-13': { type: 'event',   label: 'First Day of Sunday School 2026-2027' },
    '2026-9-20': { type: 'class' },
    '2026-9-27': { type: 'class' },

    // October 2026
    '2026-10-4':  { type: 'class' },
    '2026-10-11': { type: 'class' },
    '2026-10-18': { type: 'class' },
    '2026-10-25': { type: 'class' },

    // November 2026
    '2026-11-1':  { type: 'class' },
    '2026-11-8':  { type: 'class' },
    '2026-11-15': { type: 'class' },
    '2026-11-22': { type: 'class' },
    '2026-11-29': { type: 'holiday', label: 'School Closed — Thanksgiving Break' },

    // December 2026
    '2026-12-6':  { type: 'class' },
    '2026-12-13': { type: 'event',   label: 'Mid-Terms' },
    '2026-12-20': { type: 'holiday', label: 'School Closed — Winter Break' },
    '2026-12-27': { type: 'holiday', label: 'School Closed — Winter Break' },

    // January 2027
    '2027-1-3':  { type: 'class' },
    '2027-1-10': { type: 'class' },
    '2027-1-17': { type: 'class' },
    '2027-1-24': { type: 'class' },
    '2027-1-31': { type: 'class' },

    // February 2027
    '2027-2-7':  { type: 'event',   label: 'First Day of Ramadan' },
    '2027-2-14': { type: 'class' },
    '2027-2-21': { type: 'class' },
    '2027-2-28': { type: 'holiday', label: 'School Closed — Ramadan' },

    // March 2027
    '2027-3-1':  { type: 'event',   label: 'Qadr Night' },
    '2027-3-7':  { type: 'class' },
    '2027-3-10': { type: 'event',   label: 'Eid Ul-Fitr' },
    '2027-3-14': { type: 'class' },
    '2027-3-21': { type: 'class' },
    '2027-3-28': { type: 'holiday', label: 'School Closed — Spring Break' },

    // April 2027
    '2027-4-4':  { type: 'class' },
    '2027-4-11': { type: 'class' },
    '2027-4-18': { type: 'class' },
    '2027-4-25': { type: 'class' },

    // May 2027
    '2027-5-2':  { type: 'class' },
    '2027-5-9':  { type: 'class' },
    '2027-5-16': { type: 'event',   label: 'Final Exam' },
    '2027-5-17': { type: 'event',   label: 'Eid Ul-Azha' },
    '2027-5-23': { type: 'event',   label: 'Sunday School Graduation Picnic 🎓' },
    '2027-5-25': { type: 'event',   label: 'Eid Al-Ghadir' },
  };

  const _today = new Date();
  let calYear = _today.getFullYear(), calMonth = _today.getMonth(); // starts on current month

  const monthNames = ['January','February','March','April','May','June',
                      'July','August','September','October','November','December'];

  function renderCalendar() {
    const label = document.getElementById('calMonthLabel');
    const grid  = document.getElementById('calDates');
    if (!label || !grid) return;

    label.textContent = monthNames[calMonth] + ' ' + calYear;
    grid.innerHTML = '';

    const firstDay = new Date(calYear, calMonth, 1).getDay();
    const daysInMonth = new Date(calYear, calMonth + 1, 0).getDate();
    const today = new Date();

    // empty cells
    for (let i = 0; i < firstDay; i++) {
      const empty = document.createElement('div');
      empty.className = 'cal-date empty';
      grid.appendChild(empty);
    }

    for (let d = 1; d <= daysInMonth; d++) {
      const cell = document.createElement('div');
      const key  = calYear + '-' + (calMonth + 1) + '-' + d;
      const date = new Date(calYear, calMonth, d);
      const isSunday = date.getDay() === 0;
      const isToday  = date.toDateString() === today.toDateString();
      const ev = events[key];

      let classes = 'cal-date';
      if (isSunday) classes += ' sunday';
      if (isToday)  classes += ' today';
      if (ev) {
        if (ev.type === 'class')   classes += ' has-class';
        if (ev.type === 'event')   classes += ' has-event';
        if (ev.type === 'holiday') classes += ' holiday';
      }

      cell.className = classes;
      cell.textContent = d;

      if (ev && ev.label) {
        const dot = document.createElement('div');
        dot.className = 'cal-dot';
        cell.appendChild(dot);
        cell.title = ev.label;
      }

      grid.appendChild(cell);
    }
  }

  function changeMonth(dir) {
    calMonth += dir;
    if (calMonth > 11) { calMonth = 0; calYear++; }
    if (calMonth < 0)  { calMonth = 11; calYear--; }
    renderCalendar();
  }

  renderCalendar();

  // ── UPCOMING EVENTS SIDEBAR (only future events, auto-updates) ──
  function renderUpcomingEvents() {
    const panel = document.getElementById('upcomingEventsList');
    if (!panel) return;

    const now = new Date();
    now.setHours(0, 0, 0, 0); // compare date only

    // Build full event list with real dates and labels
    const allEvents = [
      { date: new Date(2026,8,13),  type: 'event',   label: 'First Day of Sunday School',         meta: 'Sunday · Welcome back! 2026-2027' },
      { date: new Date(2026,10,29), type: 'holiday', label: 'School Closed — Thanksgiving Break', meta: 'Sunday · School Closed' },
      { date: new Date(2026,11,13), type: 'event',   label: 'Mid-Terms',                          meta: 'Sunday · 10:00 AM · All Classrooms' },
      { date: new Date(2026,11,20), type: 'holiday', label: 'School Closed — Winter Break',       meta: 'Sunday · School Closed' },
      { date: new Date(2026,11,27), type: 'holiday', label: 'School Closed — Winter Break',       meta: 'Sunday · School Closed' },
      { date: new Date(2027,1,7),   type: 'event',   label: 'First Day of Ramadan',               meta: 'Monday · Ramadan Mubarak!' },
      { date: new Date(2027,1,28),  type: 'holiday', label: 'School Closed — Ramadan',            meta: 'Sunday · School Closed' },
      { date: new Date(2027,2,1),   type: 'event',   label: 'Qadr Night',                         meta: 'Monday · Special Program' },
      { date: new Date(2027,2,10),  type: 'event',   label: 'Eid Ul-Fitr 🌙',                     meta: 'Wednesday · Eid Mubarak!' },
      { date: new Date(2027,2,28),  type: 'holiday', label: 'School Closed — Spring Break',       meta: 'Sunday · School Closed' },
      { date: new Date(2027,4,16),  type: 'event',   label: 'Final Exam',                         meta: 'Sunday · 10:00 AM · All Classrooms' },
      { date: new Date(2027,4,23),  type: 'event',   label: 'Sunday School Graduation Picnic 🎓', meta: 'Sunday · Last Day of School Year' },
      { date: new Date(2027,4,25),  type: 'event',   label: 'Eid Al-Ghadir',                      meta: 'Monday · Special Occasion' },
    ];

    const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

    // Filter to only today and future, take next 6
    const upcoming = allEvents
      .filter(ev => ev.date >= now)
      .slice(0, 6);

    if (upcoming.length === 0) {
      panel.innerHTML = '<div style="font-size:13px;color:rgba(255,255,255,0.5);padding:16px 0;">No upcoming events. Check back soon!</div>';
      return;
    }

    panel.innerHTML = upcoming.map(ev => {
      const tagClass = ev.type === 'event' ? 'cal-event-tag gold' : ev.type === 'holiday' ? 'cal-event-tag gold' : 'cal-event-tag';
      const tagLabel = ev.type === 'event' ? 'Event' : ev.type === 'holiday' ? 'No School' : 'Class';
      return `
        <div class="cal-event-item">
          <div class="cal-event-date-box">
            <span class="ev-month">${months[ev.date.getMonth()]}</span>
            <span class="ev-day">${ev.date.getDate()}</span>
          </div>
          <div class="cal-event-info">
            <span class="${tagClass}">${tagLabel}</span>
            <div class="cal-event-name">${ev.label}</div>
            <div class="cal-event-meta">${ev.meta}</div>
          </div>
        </div>`;
    }).join('');
  }

  renderUpcomingEvents();
</script>
</body>
</html>
